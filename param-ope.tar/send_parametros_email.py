from email.message import EmailMessage
import requests
from send_msg import send
from jinja2 import Template
from apscheduler.schedulers.blocking import BlockingScheduler
from pytz import timezone
from datetime import datetime

sender_email = "aurora@grupoolhodagua.com.br"
receiver_email = "ti.recife@grupoolhodagua.com.br"
cc_email = [
    'rafael.pontes@giasa.com.br',
    'antonio.jefferson@giasa.com.br',
    'eduardo.william@giasa.com.br',
    'rosinaldo.bezerra@giasa.com.br',
    'lideres.producao@giasa.com.br',
    'armstrong.vilar@giasa.com.br',
    'jose.itamar@giasa.com.br',
    'edvaldo.luiz@giasa.com.br',
    'maria.aquino@giasa.com.br',
    'fabiano.rafael@giasa.com.br',
    'valberto.araujo@giasa.com.br',
    'rosilda.pereira@giasa.com.br',
    'gilbertofilho@grupoolhodagua.com.br',
    'lab.industrial@giasa.com.br',
    'lab.sacarose@giasa.com.br',
    'carlos.eduardo@giasa.com.br',
    'lucas.silva@giasa.com.br'
]

# Nome da unidade (usina) que aparece no título do relatório
UNIDADE = "GIASA"
# URL da API (ajuste para localhost se rodar na mesma máquina)
API_URL = 'http://10.10.12.200:8525/api/get_parametros_op'

def format_value(value):
    """Converte None / vazio em '-' mantendo o formato original (vírgula decimal)."""
    if value is None or value == '' or value == 'null':
        return '-'
    return str(value)

def send_email_parametros():
    # 1. Busca os dados da API
    try:
        response = requests.get(API_URL, timeout=30)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        print(f"Erro ao buscar os dados: {e}")
        data = []

    # 2. Agrupa por campo "grupo"
    grupos = {}
    for item in data:
        grupo = item.get('grupo') or 'SEM GRUPO'
        if grupo not in grupos:
            grupos[grupo] = []
        grupos[grupo].append(item)

    # 3. Data de exibição no formato dd/aaa (ex: 27/ago)
    meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun',
             'jul', 'ago', 'set', 'out', 'nov', 'dez']
    agora = datetime.now()
    data_exibir = f"{agora.day:02d}/{meses[agora.month - 1]}"

    # 4. Renderiza o template Jinja2
    with open('template.html', 'r', encoding='utf-8') as file:
        html_template = file.read()

    template = Template(html_template)
    html_final = template.render(
        unidade=UNIDADE,
        data=data_exibir,
        grupos=grupos,
        format_value=format_value
    )

    # 5. Monta o e-mail
    msg = EmailMessage()
    msg["to"] = receiver_email
    msg["cc"] = cc_email
    msg["from"] = sender_email
    msg["subject"] = f"Parâmetros Operacionais de Processo - {UNIDADE}"
    msg.set_content(html_final, subtype="html")
    msg.make_related()

    # 6. Envia
    try:
        send(msg, sender_email)
        print("E-mail com Parâmetros Operacionais enviado com sucesso!", flush=True)
    except Exception as e:
        print(f"Erro ao disparar e-mail via send_msg: {e}", flush=True)

# Execução com Agendador
if __name__ == "__main__":
    try:
        scheduler = BlockingScheduler(timezone=timezone('America/Sao_Paulo'))
        scheduler.add_job(
            send_email_parametros, "cron", hour="9,13,17,21,1,5", minute="0", id="job_parametros"
        )

        print("Agendador iniciado com sucesso.", flush=True)

        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("Agendador encerrado manualmente.", flush=True)
    except Exception as e:
        print(f"Agendador encerrado devido a falha crítica: {e}", flush=True)